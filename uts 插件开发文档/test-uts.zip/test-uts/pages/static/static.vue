<template>
    <image :src="logo"></image>
</template>
<script lang="ts" setup>
import { getLogoPath } from '../../uni_modules/test-uts-static'
const logo = getLogoPath()
</script>