<template>
    <view class="content">
        <navigator url="/pages/test/test">测试 ProxyModule</navigator>
        <navigator url="/pages/battery/battery">获取电池电量</navigator>
        <navigator url="/pages/static/static">静态资源</navigator>
    </view>
</template>
<style>
    .content {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
    }

    navigator {
        padding: 32rpx;
        font-size: 18px;
    }
</style>
