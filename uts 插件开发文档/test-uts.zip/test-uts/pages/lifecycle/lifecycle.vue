<template>
    <view>当前电量：{{ capacity }}</view>
</template>
<script lang="ts" setup>

</script>