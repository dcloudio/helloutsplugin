type AsyncOptions = {
  type: string;
  success(res: string): void;
  fail(res: string): void;
  complete(res: string): void;
};
type TestOptions = {
  name: string;
  callback: (res: string) => void;
};
export declare const MAX: 100;
export declare function testSync(msg: string): { msg: string };
export declare function testSyncError(): void;
export declare function testSyncWithCallback(opts: AsyncOptions): {
  name: string;
};
export declare function testAsync(
  opts: AsyncOptions
): Promise<{ name: string }>;

export declare class Test {
  id: number;
  name: string;
  static type: string;
  constructor(id: number, options: TestOptions);
  static testClassStaticSyncWithCallback(opts: AsyncOptions): {
    name: string;
  };
  static testClassStaticAsync(opts: AsyncOptions): Promise<{ name: string }>;
  testClassSyncWithCallback(opts: AsyncOptions): {
    name: string;
  };
  testClassAsync(opts: AsyncOptions): Promise<{ name: string }>;
}
